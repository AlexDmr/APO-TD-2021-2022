package uga.l3miage.apo.td9;

class A {
    public A() {
        System.out.println("> Constructeur de A()");
        afficher();
    }

    public void afficher() {
        System.out.println("> Affichage de A");
    }
}
