package uga.l3miage.apo.td9;

/**
 * L3 MIAGE APO TD9.1
 *
 */
public class App {
    public static void main(String[] args) {
        System.out.println("A objetAA = new A();");
        A objetAA = new A();
        System.out.println("A objetAB = new B();");
        A objetAB = new B();
        // System.out.println("B objetBA = new A();");
        // B objetBA = new A();
    }
}
